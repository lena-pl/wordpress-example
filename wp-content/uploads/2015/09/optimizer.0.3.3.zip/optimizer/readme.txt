

Demo Image and Screenshot image are from pixabay.com and is Licensed under CC0 licenses

slide.jpg :		https://unsplash.com/photos/6xqAK6oAeHA/
welcome_textbg.jpg :	https://unsplash.com/photos/6xqAK6oAeHA/

Images Created BY Layerthemes:
-------------------------------
upgrade_banner.jpg :	Created by Layerthemes and released under GPL v2
slide_icon.png :	Created by Layerthemes and released under GPL v2


-------------------------------------------------------
Credits:
-------------------------------------------------------
Font Awesome
http://fortawesome.github.io/Font-Awesome/license/
License: SIL OFL 1.1

Animate.css 
http://daneden.me/animate
Licensed under the MIT license - http://opensource.org/licenses/MIT

The Final Countdown for jQuery
http://hilios.github.io/jQuery.countdown/
Licensed under the MIT License.

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/
Licensed under the BSD License.

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/
Licensed under the MIT License.

jQuery Waypoints
https://github.com/imakewebthings/jquery-waypoints/
Licensed under the MIT license.

Sidr
https://github.com/artberri/sidr
Licensed under the MIT license.

waitForImages jQuery Plugin
https://github.com/alexanderdickson/waitForImages
Licensed under the MIT license.

pace
https://github.com/HubSpot/pace/
Licensed under the MIT license.

jQuery Parallax
http://www.ianlunn.co.uk/plugins/jquery-parallax/
Dual licensed under the MIT and GPL licenses

HTML5 Placeholder jQuery Plugin
https://github.com/mathiasbynens/jquery-placeholder
Licensed under the MIT license.

jQuery Nivo Slider
http://nivo.dev7studios.com
Licensed under the MIT license.

SmoothScroll for websites v1.2.1
https://gist.github.com/galambalazs/6477177/
Licensed under the terms of the MIT license.

Jquery matchHeight
http://brm.io/jquery-match-height/
Licensed under the terms of the MIT license.


miniTip v1.5.3
https://github.com/goldfire/miniTip
Licensed under the terms of the MIT license.